--
-- PostgreSQL database dump
--

\restrict 2EFeBx1FxdJnlQ7NlHbLW1nKumiQwOq1cSwtx4BOzPQfBsjR36ja492x2IrXysu

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS public.users_username_idx;
DROP INDEX IF EXISTS public.questions_user_id_idx;
DROP INDEX IF EXISTS public.questions_answered_idx;
DROP INDEX IF EXISTS public.news_publications_user_id_idx;
DROP INDEX IF EXISTS public.news_publications_status_idx;
DROP INDEX IF EXISTS public.moderators_user_id_idx;
DROP INDEX IF EXISTS public.contracts_physical_user_id_idx;
DROP INDEX IF EXISTS public.contracts_physical_status_idx;
DROP INDEX IF EXISTS public.contracts_physical_is_hidden_idx;
DROP INDEX IF EXISTS public.contracts_legal_user_id_idx;
DROP INDEX IF EXISTS public.contracts_legal_status_idx;
DROP INDEX IF EXISTS public.contracts_legal_is_hidden_idx;
DROP INDEX IF EXISTS public.agnks_users_user_id_idx;
DROP INDEX IF EXISTS public.admin_actions_created_at_idx;
DROP INDEX IF EXISTS public.admin_actions_admin_id_idx;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.questions DROP CONSTRAINT IF EXISTS questions_pkey;
ALTER TABLE IF EXISTS ONLY public.news_publications DROP CONSTRAINT IF EXISTS news_publications_pkey;
ALTER TABLE IF EXISTS ONLY public.moderators DROP CONSTRAINT IF EXISTS moderators_pkey;
ALTER TABLE IF EXISTS ONLY public.delayed_messages DROP CONSTRAINT IF EXISTS delayed_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.contracts_physical DROP CONSTRAINT IF EXISTS contracts_physical_pkey;
ALTER TABLE IF EXISTS ONLY public.contracts_legal DROP CONSTRAINT IF EXISTS contracts_legal_pkey;
ALTER TABLE IF EXISTS ONLY public.bot_settings DROP CONSTRAINT IF EXISTS bot_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.agnks_users DROP CONSTRAINT IF EXISTS agnks_users_pkey;
ALTER TABLE IF EXISTS ONLY public.admin_actions DROP CONSTRAINT IF EXISTS admin_actions_pkey;
ALTER TABLE IF EXISTS public.questions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.news_publications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.delayed_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contracts_physical ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contracts_legal ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.admin_actions ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.questions_id_seq;
DROP TABLE IF EXISTS public.questions;
DROP SEQUENCE IF EXISTS public.news_publications_id_seq;
DROP TABLE IF EXISTS public.news_publications;
DROP TABLE IF EXISTS public.moderators;
DROP SEQUENCE IF EXISTS public.delayed_messages_id_seq;
DROP TABLE IF EXISTS public.delayed_messages;
DROP SEQUENCE IF EXISTS public.contracts_physical_id_seq;
DROP TABLE IF EXISTS public.contracts_physical;
DROP SEQUENCE IF EXISTS public.contracts_legal_id_seq;
DROP TABLE IF EXISTS public.contracts_legal;
DROP TABLE IF EXISTS public.bot_settings;
DROP TABLE IF EXISTS public.agnks_users;
DROP SEQUENCE IF EXISTS public.admin_actions_id_seq;
DROP TABLE IF EXISTS public.admin_actions;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_actions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_actions (
    id integer NOT NULL,
    admin_id bigint NOT NULL,
    action text NOT NULL,
    target_id bigint,
    target_username text,
    details text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.admin_actions OWNER TO postgres;

--
-- Name: admin_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_actions_id_seq OWNER TO postgres;

--
-- Name: admin_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_actions_id_seq OWNED BY public.admin_actions.id;


--
-- Name: agnks_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agnks_users (
    user_id bigint NOT NULL,
    username text,
    added_by bigint,
    added_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true
);


ALTER TABLE public.agnks_users OWNER TO postgres;

--
-- Name: bot_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bot_settings (
    key text NOT NULL,
    value text
);


ALTER TABLE public.bot_settings OWNER TO postgres;

--
-- Name: contracts_legal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contracts_legal (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    username text,
    organization_name text NOT NULL,
    postal_address text NOT NULL,
    legal_address text,
    phone text NOT NULL,
    activity_type text NOT NULL,
    okpo text,
    unp text NOT NULL,
    account_number text NOT NULL,
    bank_name text NOT NULL,
    bank_bic text NOT NULL,
    bank_address text NOT NULL,
    signatory_name text NOT NULL,
    authority_basis text NOT NULL,
    "position" text NOT NULL,
    email text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status text DEFAULT 'pending'::text,
    site_sync_status text DEFAULT 'pending'::text,
    site_contract_id integer,
    is_hidden boolean DEFAULT false
);


ALTER TABLE public.contracts_legal OWNER TO postgres;

--
-- Name: contracts_legal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contracts_legal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contracts_legal_id_seq OWNER TO postgres;

--
-- Name: contracts_legal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contracts_legal_id_seq OWNED BY public.contracts_legal.id;


--
-- Name: contracts_physical; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contracts_physical (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    username text,
    full_name text NOT NULL,
    passport_id text NOT NULL,
    passport_issue_date text NOT NULL,
    passport_issued_by text NOT NULL,
    living_address text NOT NULL,
    registration_address text,
    phone text NOT NULL,
    email text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status text DEFAULT 'pending'::text,
    site_sync_status text DEFAULT 'pending'::text,
    site_contract_id integer,
    is_hidden boolean DEFAULT false
);


ALTER TABLE public.contracts_physical OWNER TO postgres;

--
-- Name: contracts_physical_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contracts_physical_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contracts_physical_id_seq OWNER TO postgres;

--
-- Name: contracts_physical_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contracts_physical_id_seq OWNED BY public.contracts_physical.id;


--
-- Name: delayed_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delayed_messages (
    id integer NOT NULL,
    content_type text NOT NULL,
    text_content text,
    photo_path text,
    send_time timestamp without time zone NOT NULL,
    status text NOT NULL,
    recipient_type text NOT NULL,
    recipient_id bigint,
    created_by bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approved_by bigint,
    attempts integer DEFAULT 0,
    approved_at timestamp without time zone
);


ALTER TABLE public.delayed_messages OWNER TO postgres;

--
-- Name: delayed_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delayed_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.delayed_messages_id_seq OWNER TO postgres;

--
-- Name: delayed_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delayed_messages_id_seq OWNED BY public.delayed_messages.id;


--
-- Name: moderators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.moderators (
    user_id bigint NOT NULL,
    username text,
    added_by bigint,
    added_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true
);


ALTER TABLE public.moderators OWNER TO postgres;

--
-- Name: news_publications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.news_publications (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    username text,
    title text NOT NULL,
    content text NOT NULL,
    site_news_id integer,
    status text NOT NULL,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    published_at timestamp without time zone
);


ALTER TABLE public.news_publications OWNER TO postgres;

--
-- Name: news_publications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.news_publications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.news_publications_id_seq OWNER TO postgres;

--
-- Name: news_publications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.news_publications_id_seq OWNED BY public.news_publications.id;


--
-- Name: questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.questions (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    username text,
    question text NOT NULL,
    answer text,
    answered_by text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    answered_at timestamp without time zone,
    skipped_at timestamp without time zone
);


ALTER TABLE public.questions OWNER TO postgres;

--
-- Name: questions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.questions_id_seq OWNER TO postgres;

--
-- Name: questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.questions_id_seq OWNED BY public.questions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id bigint NOT NULL,
    username text,
    first_name text,
    last_name text,
    registered_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_activity timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: admin_actions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_actions ALTER COLUMN id SET DEFAULT nextval('public.admin_actions_id_seq'::regclass);


--
-- Name: contracts_legal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts_legal ALTER COLUMN id SET DEFAULT nextval('public.contracts_legal_id_seq'::regclass);


--
-- Name: contracts_physical id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts_physical ALTER COLUMN id SET DEFAULT nextval('public.contracts_physical_id_seq'::regclass);


--
-- Name: delayed_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delayed_messages ALTER COLUMN id SET DEFAULT nextval('public.delayed_messages_id_seq'::regclass);


--
-- Name: news_publications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news_publications ALTER COLUMN id SET DEFAULT nextval('public.news_publications_id_seq'::regclass);


--
-- Name: questions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions ALTER COLUMN id SET DEFAULT nextval('public.questions_id_seq'::regclass);


--
-- Data for Name: admin_actions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_actions (id, admin_id, action, target_id, target_username, details, created_at) FROM stdin;
1	233014097	add_moderator	830684363	\N	Добавлен модератор 830684363	2026-03-20 07:58:22.867801
2	233014097	add_moderator	830684363	\N	Добавлен модератор 830684363	2026-03-20 08:00:11.027867
3	233014097	add_moderator	830684363	\N	Добавлен модератор 830684363	2026-03-20 08:00:34.208558
4	233014097	add_moderator	830684363	\N	Добавлен модератор 830684363	2026-03-20 08:02:54.702002
5	233014097	add_moderator	830684363	\N	Добавлен модератор 830684363	2026-03-20 08:34:29.912402
6	233014097	add_agnks	6306615927	\N	Добавлен AGNKS 6306615927	2026-03-20 08:34:29.93119
7	233014097	remove_agnks	6306615927	\N	Удалён AGNKS 6306615927	2026-03-20 08:38:00.442957
8	233014097	add_moderator	830684363	\N	Добавлен модератор 830684363	2026-03-20 08:38:05.887211
9	233014097	add_agnks	6306615927	\N	Добавлен AGNKS 6306615927	2026-03-20 08:38:05.8959
10	233014097	remove_agnks	6306615927	\N	Удалён AGNKS 6306615927	2026-03-20 08:38:11.172913
11	233014097	add_moderator	830684363	\N	Добавлен модератор 830684363	2026-03-20 08:38:49.535534
12	233014097	add_moderator	830684363	\N	Добавлен модератор 830684363	2026-03-20 09:39:14.188866
13	233014097	add_moderator	830684363	\N	Добавлен модератор 830684363	2026-03-20 09:41:10.971977
14	233014097	add_moderator	830684363	\N	Добавлен модератор 830684363	2026-03-20 09:49:33.591441
15	233014097	add_agnks	6306615927	\N	Добавлен AGNKS 6306615927	2026-03-20 10:13:20.142409
16	233014097	hide_physical_contract	8	\N	Скрыт договор physical ID 8 из списка (пользователь: 233014097)	2026-03-20 12:08:26.831048
17	233014097	add_moderator	969550236	Danya_XA4	Добавлен модератор Danya_XA4	2026-03-24 09:50:39.305645
18	233014097	add_agnks	830684363	katekharytonovich	Добавлен AGNKS katekharytonovich	2026-03-24 10:39:12.738233
19	233014097	add_moderator	6306615927	\N	Добавлен модератор 6306615927	2026-03-24 10:39:47.7854
20	233014097	remove_moderator	969550236	\N	Удалён модератор 969550236	2026-03-24 12:42:58.629789
21	233014097	remove_moderator	6306615927	\N	Удалён модератор 6306615927	2026-03-24 12:43:09.329933
22	233014097	remove_agnks	6306615927	\N	Удалён AGNKS 6306615927	2026-03-24 12:43:20.314818
23	233014097	remove_agnks	830684363	\N	Удалён AGNKS 830684363	2026-03-24 12:43:48.576299
24	233014097	add_agnks	969550236	Danya_XA4	Добавлен AGNKS Danya_XA4	2026-03-24 16:41:44.679428
25	233014097	add_moderator	7267201796	\N	Добавлен модератор 7267201796	2026-03-25 06:14:49.326437
26	233014097	remove_moderator	830684363	\N	Удалён модератор 830684363	2026-03-25 07:14:52.162188
27	233014097	remove_agnks	969550236	\N	Удалён AGNKS 969550236	2026-03-25 08:04:58.435798
28	233014097	add_agnks	7267201796	\N	Добавлен AGNKS 7267201796	2026-03-25 08:05:15.403703
29	233014097	remove_moderator	7267201796	\N	Удалён модератор 7267201796	2026-03-25 08:05:28.003738
30	233014097	remove_agnks	7267201796	\N	Удалён AGNKS 7267201796	2026-03-25 08:13:21.998444
31	233014097	add_moderator	7267201796	\N	Добавлен модератор 7267201796	2026-03-25 08:13:28.879476
32	233014097	add_agnks	969550236	Danya_XA4	Добавлен AGNKS Danya_XA4	2026-03-25 08:27:18.797743
33	233014097	remove_moderator	7267201796	\N	Удалён модератор 7267201796	2026-03-25 09:07:25.997073
34	233014097	add_agnks	7267201796	\N	Добавлен AGNKS 7267201796	2026-03-25 09:07:33.042344
35	233014097	remove_agnks	969550236	\N	Удалён AGNKS 969550236	2026-03-25 09:17:44.85678
36	233014097	remove_agnks	7267201796	\N	Удалён AGNKS 7267201796	2026-03-25 09:17:50.01386
37	233014097	add_agnks	7267201796	\N	Добавлен AGNKS 7267201796	2026-03-25 12:49:46.603608
38	233014097	add_moderator	969550236	Danya_XA4	Добавлен модератор Danya_XA4	2026-03-25 12:49:58.594477
39	233014097	remove_moderator	969550236	\N	Удалён модератор 969550236	2026-03-25 13:16:26.628089
40	233014097	add_agnks	969550236	Danya_XA4	Добавлен AGNKS Danya_XA4	2026-03-25 13:16:34.168293
41	233014097	remove_agnks	7267201796	\N	Удалён AGNKS 7267201796	2026-03-25 16:36:13.71657
42	233014097	remove_agnks	969550236	\N	Удалён AGNKS 969550236	2026-03-25 16:36:17.916921
43	233014097	add_moderator	830684363	katekharytonovich	Добавлен модератор katekharytonovich	2026-03-25 16:36:29.493196
44	233014097	add_agnks	1623979667	\N	Добавлен AGNKS 1623979667	2026-03-26 08:03:25.11792
45	233014097	add_agnks	7267201796	\N	Добавлен AGNKS 7267201796	2026-03-26 08:03:52.135729
\.


--
-- Data for Name: agnks_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agnks_users (user_id, username, added_by, added_at, is_active) FROM stdin;
6306615927	\N	233014097	2026-03-20 10:13:20.128589	f
830684363	katekharytonovich	233014097	2026-03-24 10:39:12.723716	f
969550236	Danya_XA4	233014097	2026-03-25 13:16:34.164322	f
1623979667	\N	233014097	2026-03-26 08:03:25.113462	t
7267201796	\N	233014097	2026-03-26 08:03:52.13165	t
\.


--
-- Data for Name: bot_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bot_settings (key, value) FROM stdin;
welcome_message	Добро пожаловать в бот METAN.BY!
notify_admin_questions	1
notify_admin_contracts	1
notify_admin_errors	1
button_add_news	1
notify_moderators_news_from_admin	1
notify_moderators_news_from_agnks	1
notify_agnks_news_from_admin	1
diesel_installation	15000
cng_price	1.1
gasoline_price	2.6
diesel_price	2.6
gasoline_installation_light	3500.0
gasoline_installation_heavy	5500.0
notify_agnks_news_from_agnks	1
button_publish_to_group	1
button_contract	1
notify_admin_news	1
button_consultation	1
button_roi	1
button_experience	1
notify_moderators_questions	1
notify_moderators_contracts	1
notify_moderators_news	1
notify_agnks_news	1
button_delayed_messages	1
button_unanswered_questions	1
button_view_contracts	1
\.


--
-- Data for Name: contracts_legal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contracts_legal (id, user_id, username, organization_name, postal_address, legal_address, phone, activity_type, okpo, unp, account_number, bank_name, bank_bic, bank_address, signatory_name, authority_basis, "position", email, created_at, status, site_sync_status, site_contract_id, is_hidden) FROM stdin;
3	233014097	p_soroko	Тест	000000	123	gAAAAABpvT6Dy4hx4csuSFGAKi98l2BQ2W0CS2sl9ot7MdSnKCgm2o2gk2jq2UshoFz57Qo2oLIlg12Vaptv1JUj2ZQmjhW5cQ==	ООО"Бнал"	gAAAAABpvT6Do6MHDeBHRymMGv9fMmAYBNzV3_nA0RhceNizhRy7qfSduw9PmTudkEKAscMu-nV3UZbaGg74RYrdDPrYYBUFmA==	gAAAAABpvT6DAbwBZZeBHfi8rLGUcyO3aQpzTsYFDcMdFazHSIexTxVI4NlBBvZRluNKCrMo1FlGFrf0A5Sl_iGgwfkB4fcDLw==	gAAAAABpvT6Dzk5Lle5CZgKSpoQEM4b3cR3Re4qgt5WVw8ZQdMEcUN6Jo2JH-j_aJLz6thsXu6160DQ9uo7AFHO-uC-QpVxbvVHxipp5Ww2eP9ie6oI7yDc=	123	123	123	123	123	123	hn@fn.ru	2026-03-20 15:33:07.063829	pending	success	11051	f
\.


--
-- Data for Name: contracts_physical; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contracts_physical (id, user_id, username, full_name, passport_id, passport_issue_date, passport_issued_by, living_address, registration_address, phone, email, created_at, status, site_sync_status, site_contract_id, is_hidden) FROM stdin;
6	233014097	p_soroko	Проп	gAAAAABoPCMBABWjWpGqf1DQcuvd9Qaj5Ra0MPZiDVtAIPn4bR0W7wm5E2ZoZp26ZU4Db8ExP7GoKsUejNJKJqfrgQR12f2Lpg==	20.04.2018	Раорао	Оаовдр	Оаовдр	gAAAAABoPCMBvGT1kzFuOm_MkmCUs40VB8Kuvog9BjHRxcg3U2e6RiR-QEJA7EwTOlRVsBTYVd8z22elReXtM3T1UBgDs-brRw==	Роар@па.ап	2025-06-01 12:53:05.0709	processed	pending	\N	f
9	233014097	p_soroko	Тест Тест	gAAAAABpu6zsgPqS-px1cVehpETYnsFcEupOJbQSlmBCQX-82ad8PbQ20eI5c8X34ZCupN3N542EDIRJIabsA-d8mlym9yggVg==	11.12.2193	никем	123	123	gAAAAABpu6zsL99GfT8nAAWw8owEDXFpJcDKMSPpe8n0xW7kDlXCgVJJFK_aLfAHI6afUlO6_pjkekj_A3wRSMl_OAyojdSmOg==	уа@nm.ru	2026-03-19 10:59:40.911059	pending	success	11044	f
7	233014097	p_soroko	Й	gAAAAABpua9LU3-xe3SQN1YL87rjJxiQWN0jy4gNCEXEEIfxmHFtVmHy_s3WHrjXCBo1hDdq1tDv49hdWGvVDiStIc-s9DKvqQ==	20.12.1999	Оп	Р	Р	gAAAAABpua9LqOKZ2KUHmZ-MPBqyg0kBvNic7g4TA0REUPIrC8Tj3JaMBpkc6ey8tih2-Cjf4g-As-2cNQllFruxGYeXZYPPsg==	Tt@mk.ru	2026-03-17 22:45:15.680102	processed	pending	\N	f
8	233014097	p_soroko	Сороко	gAAAAABpu5qDF4YFgeRp0ZT22OuTs8rQCTwboEDKbB5BiS2WgUqHOnBEvBfY-aODqRwJ6kvMVsQQMuoC6X-ftHrLQzt6DgzgxQ==	20.04.1119	сам себе	220000, Минск, Мержинского 4	Минск Мержинского 5	gAAAAABpu5qDHpKIqJM5MxqrU7HkyI5RYg2iPzxgHsVH80mZm98INx2wt5F7uetz_MTzeXLwyN0Wi6I3gEsVaWHFpNKDWOV9iw==	test@metan.by	2026-03-19 09:41:07.739687	hidden	pending	\N	f
\.


--
-- Data for Name: delayed_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delayed_messages (id, content_type, text_content, photo_path, send_time, status, recipient_type, recipient_id, created_by, created_at, approved_by, attempts, approved_at) FROM stdin;
1	photo	\N	temp/delayed_photos/AgACAgIAAxkBAAIjOmgu5ugWQdkWFJojRhhNxFS7iRm4AAIh7TEbCkl4SZM1K42Hmt7IAQADAgADeQADNgQ.jpg	2025-05-22 11:58:00	blocked	all	\N	233014097	2025-05-22 08:57:36.101628	233014097	0	2025-05-22 08:57:37.81604
2	photo	\N	temp/delayed_photos/AgACAgIAAxkBAAIjOmgu5ugWQdkWFJojRhhNxFS7iRm4AAIh7TEbCkl4SZM1K42Hmt7IAQADAgADeQADNgQ.jpg	2025-05-22 14:15:00	blocked	all	\N	233014097	2025-05-22 11:15:02.319523	233014097	0	2025-05-22 11:15:04.728921
3	photo	\N	temp/delayed_photos/AgACAgIAAxkBAAIjOmgu5ugWQdkWFJojRhhNxFS7iRm4AAIh7TEbCkl4SZM1K42Hmt7IAQADAgADeQADNgQ.jpg	2025-05-22 14:21:00	sent	all	\N	233014097	2025-05-22 11:19:37.331737	233014097	0	2025-05-22 11:19:41.1759
4	photo_with_text	тест	temp/delayed_photos/AgACAgIAAxkBAAIkBGgvIufMFOfRGiDyeX4YIzoPegWvAAIP7zEbCkl4SbYjwdWmXwNzAQADAgADeQADNgQ.jpg	2025-05-22 16:14:00	sent	all	\N	233014097	2025-05-22 16:13:50.128478	233014097	0	2025-05-22 16:13:54.178578
5	text	Тест	\N	2025-05-23 13:10:00	sent	all	\N	233014097	2025-05-23 13:09:16.342867	233014097	0	2025-05-23 13:09:18.303204
6	photo	\N	temp/delayed_photos/AgACAgIAAxkBAAIoGmg0Xsjhxaeygt3cPMeCWN9TxJL7AAIm8DEbf5yhSRQXI_5RM1Z6AQADAgADeQADNgQ.jpg	2025-05-26 15:35:00	blocked	moderators	\N	233014097	2025-05-26 15:30:29.91567	233014097	0	2025-05-26 15:31:02.509135
7	photo	\N	temp/delayed_photos/AgACAgIAAxkBAAIuNGmYrRzstNY4qAAB5KfIPpseZtpzKgACWBNrG6-hyUidQupcfQgaGQEAAwIAA3gAAzoE.jpg	2026-02-20 21:54:00	sent	specific	670591083	233014097	2026-02-20 21:54:26.967954	233014097	0	2026-02-20 21:54:34.448071
8	photo	\N	temp/delayed_photos/AgACAgIAAxkBAAIuRWmYrkeEcp_63U4BjjezjiCvPcGUAAJmE2sbr6HJSAdaA-JzGLayAQADAgADeAADOgQ.jpg	2026-02-20 21:59:00	sent	specific	670591083	233014097	2026-02-20 21:56:46.118302	233014097	0	2026-02-20 21:56:49.119769
9	text	123	\N	2026-03-19 11:59:00	sent	specific	233014097	233014097	2026-03-19 11:58:01.074852	233014097	0	2026-03-19 11:58:03.865078
10	photo	\N	temp/delayed_photos/AgACAgIAAxkBAAIwFGm7ysJM2kG6R6MtEoma7Mo8AAEt3wACTRRrG9qm4UmduysHiMtCCQEAAwIAA3gAAzoE.jpg	2026-03-19 13:09:00	sent	specific	233014097	233014097	2026-03-19 13:08:02.027632	233014097	0	2026-03-19 13:08:06.945513
\.


--
-- Data for Name: moderators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.moderators (user_id, username, added_by, added_at, is_active) FROM stdin;
6306615927	\N	233014097	2026-03-24 10:39:47.767811	f
7267201796	\N	233014097	2026-03-25 08:13:28.863128	f
969550236	Danya_XA4	233014097	2026-03-25 12:49:58.589755	f
830684363	katekharytonovich	233014097	2026-03-25 16:36:29.489029	t
\.


--
-- Data for Name: news_publications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.news_publications (id, user_id, username, title, content, site_news_id, status, error_message, created_at, published_at) FROM stdin;
1	233014097	p_soroko	Test	Test	11040	success	\N	2026-03-19 07:47:24.830382	2026-03-19 07:47:25.186177
2	233014097	p_soroko	Тест	Тест	11041	success	\N	2026-03-19 08:42:16.851811	2026-03-19 08:42:17.140676
3	233014097	p_soroko	Тест	Примерный текст	11042	success	\N	2026-03-19 09:41:50.093653	2026-03-19 09:41:50.466592
4	233014097	p_soroko	тест	тест	\N	error	HTTP ошибка 400	2026-03-19 11:43:41.231099	\N
5	233014097	p_soroko	тест	тест	\N	error	HTTP ошибка 400	2026-03-19 11:44:00.941033	\N
6	233014097	p_soroko	тест	тсе	\N	error	HTTP ошибка 400	2026-03-19 11:45:44.511699	\N
7	233014097	p_soroko	тест	тест	\N	error	HTTP ошибка 400	2026-03-19 11:51:57.484697	\N
8	233014097	p_soroko	Test	123	11045	success	\N	2026-03-19 12:02:08.795905	2026-03-19 12:02:09.083187
9	233014097	p_soroko	test	test	11046	success	\N	2026-03-19 12:51:02.898647	2026-03-19 12:51:03.141463
10	233014097	p_soroko	Тест	Тест	11047	success	\N	2026-03-19 13:14:24.748335	2026-03-19 13:14:24.969288
11	233014097	p_soroko	Test	Test	11048	success	\N	2026-03-19 17:14:16.401038	2026-03-19 17:14:16.699127
12	233014097	p_soroko	Тест	Тест	11054	success	\N	2026-03-24 09:44:07.05605	2026-03-24 09:44:07.388238
13	233014097	p_soroko	Тест	тест	11055	success	\N	2026-03-24 09:50:18.328187	2026-03-24 09:50:18.552325
14	233014097	p_soroko	Тест	тест	11056	success	\N	2026-03-24 09:51:53.041202	2026-03-24 09:51:53.292296
15	233014097	p_soroko	тест	тест	11057	success	\N	2026-03-24 10:02:06.99322	2026-03-24 10:02:07.211156
16	233014097	p_soroko	тест	тест	11058	success	\N	2026-03-24 10:28:54.029699	2026-03-24 10:28:54.277558
17	233014097	p_soroko	Текст	Текс2	11060	success	\N	2026-03-24 16:32:48.895953	2026-03-24 16:32:49.162425
18	233014097	p_soroko	123	123	11061	success	\N	2026-03-24 16:40:58.147456	2026-03-24 16:40:58.392509
19	233014097	p_soroko	123	123	11062	success	\N	2026-03-24 16:42:01.382597	2026-03-24 16:42:01.595441
20	969550236	Danya_XA4	123	123	11063	success	\N	2026-03-24 16:42:36.987853	2026-03-24 16:42:37.196686
21	233014097	p_soroko	1	2	11066	success	\N	2026-03-25 06:14:58.869533	2026-03-25 06:14:59.450335
22	969550236	Danya_XA4	2	2⃣	11067	success	\N	2026-03-25 06:22:48.781114	2026-03-25 06:22:49.21993
23	7267201796	\N	Q	Eff	11068	success	\N	2026-03-25 08:06:06.26424	2026-03-25 08:06:06.809172
24	233014097	p_soroko	123	Ц	11069	success	\N	2026-03-25 08:11:42.445652	2026-03-25 08:11:42.921705
25	233014097	p_soroko	123	текст	11070	success	\N	2026-03-25 08:13:42.061965	2026-03-25 08:13:42.514799
26	233014097	p_soroko	123	123	11071	success	\N	2026-03-25 08:42:01.601429	2026-03-25 08:42:02.095375
27	969550236	Danya_XA4	Еер	Мрне	11072	success	\N	2026-03-25 08:43:07.219446	2026-03-25 08:43:07.692426
28	969550236	Danya_XA4	123	123	11074	success	\N	2026-03-25 09:05:59.463069	2026-03-25 09:05:59.927192
29	233014097	p_soroko	Ц	С	11075	success	\N	2026-03-25 09:06:26.508883	2026-03-25 09:06:26.982842
30	7267201796	\N	T	V	11076	success	\N	2026-03-25 09:07:51.600411	2026-03-25 09:07:52.079383
31	233014097	p_soroko	У	И	11079	success	\N	2026-03-25 13:15:54.379888	2026-03-25 13:15:54.916033
32	233014097	p_soroko	П	И	11080	success	\N	2026-03-25 13:16:57.883167	2026-03-25 13:16:58.313251
33	7267201796	\N	D	V	11081	success	\N	2026-03-25 13:17:24.192767	2026-03-25 13:17:24.675979
34	7267201796	\N	F	C	11082	success	\N	2026-03-25 13:19:33.647316	2026-03-25 13:19:34.142289
35	233014097	p_soroko	Тестовое отключение АГНКС	В связи с проведением тест будет отключена Минск 1 с 17.00	11083	success	\N	2026-03-25 16:15:58.318156	2026-03-25 16:15:58.847056
36	233014097	p_soroko	123	123	11086	success	\N	2026-03-26 11:51:06.904167	2026-03-26 11:51:07.255407
37	233014097	p_soroko	123	123	11087	success	\N	2026-03-26 11:52:53.3235	2026-03-26 11:52:53.5629
38	233014097	p_soroko	123	123	11088	success	\N	2026-03-26 11:54:25.377514	2026-03-26 11:54:25.615373
39	233014097	p_soroko	123	123	11089	success	\N	2026-03-26 12:56:49.766084	2026-03-26 12:56:50.070646
40	233014097	p_soroko	123	123	11090	success	\N	2026-03-26 13:16:08.843116	2026-03-26 13:16:09.091012
41	233014097	p_soroko	123	123	11091	success	\N	2026-03-26 13:19:38.378903	2026-03-26 13:19:38.597098
42	233014097	p_soroko	тестттттттттттттттттттттт	1234124рлдуцпоцуо йолп дйкужпл шщукп олзэщпкцу шщжрпоудкл пзукшцр пцукукцо прклурпшщцур кпш рцужкщ п	11093	success	\N	2026-03-26 13:42:22.555228	2026-03-26 13:42:22.820375
43	233014097	p_soroko	теееееееееееееееееееееееееест	теееееееееееееееееееееееееееееееееееееест	11095	success	\N	2026-03-26 14:24:15.680792	2026-03-26 14:24:15.984971
44	233014097	p_soroko	123	123	11096	success	\N	2026-03-26 14:50:48.025516	2026-03-26 14:50:48.272346
45	233014097	p_soroko	123	123	11098	success	\N	2026-03-26 14:55:04.399885	2026-03-26 14:55:04.631823
46	233014097	p_soroko	123	123	11099	success	\N	2026-03-26 14:55:15.284889	2026-03-26 14:55:15.535853
47	233014097	p_soroko	123	123	11100	success	\N	2026-03-26 15:00:23.027288	2026-03-26 15:00:23.240348
48	233014097	p_soroko	123	123	11101	success	\N	2026-03-26 15:12:09.464966	2026-03-26 15:12:09.694009
49	233014097	p_soroko	123	123	11102	success	\N	2026-03-26 15:13:40.388222	2026-03-26 15:13:40.629105
50	233014097	p_soroko	123	123	11103	success	\N	2026-03-26 15:19:21.823534	2026-03-26 15:19:22.008665
51	233014097	p_soroko	123	123	11104	success	\N	2026-03-26 15:24:37.617972	2026-03-26 15:24:37.835868
52	233014097	p_soroko	123	132	11105	success	\N	2026-03-26 15:40:30.035301	2026-03-26 15:40:30.261966
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.questions (id, user_id, username, question, answer, answered_by, created_at, answered_at, skipped_at) FROM stdin;
10	6095859689	\N	Тестовый вопрос	Тестовый ответ	p_soroko	2025-05-28 14:44:41.666467	2025-05-28 14:54:24.959664	\N
12	233014097	p_soroko	Аоытаро	Вопвивв	p_soroko	2025-06-01 12:47:35.104782	2025-06-01 12:48:40.223896	\N
11	233014097	p_soroko	🔧 Модераторское меню	\N	\N	2025-05-29 10:26:39.891509	\N	2025-06-12 06:59:57.774971
14	1623979667	\N	Добрый день.	Добрый	p_soroko	2025-08-12 11:00:03.670328	2025-08-12 11:00:16.395594	\N
13	965777550	yuliyashe_17	Бла бла	\N	\N	2025-07-26 11:32:10.485865	\N	2025-08-12 11:00:38.249347
15	233014097	p_soroko	📊 Статистика	\N	\N	2025-12-19 16:27:41.334055	\N	2026-02-20 21:44:44.034208
16	670591083	gangsta_shits	Здравствуйте, есть ли в Лидском районе заправка метаном?	Здравствуйте,\nАдрес: Лидский р-н, д. Островля	p_soroko	2026-02-20 21:40:51.590947	2026-02-20 21:47:49.255411	\N
17	233014097	p_soroko	Кнпаерм	Порчро	p_soroko	2026-03-13 13:18:07.965152	2026-03-13 13:19:13.094966	\N
19	233014097	p_soroko	123	\N	\N	2026-03-26 14:46:07.081966	\N	\N
18	969550236	Danya_XA4	🔧 Модераторское меню	\N	\N	2026-03-24 10:01:22.657723	\N	2026-03-26 14:46:38.486197
20	233014097	p_soroko	345	\N	\N	2026-03-26 15:29:57.184303	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, username, first_name, last_name, registered_at, last_activity) FROM stdin;
1194860422	\N	@nt0n_U	\N	2025-05-23 14:55:08.23119	2025-05-23 14:55:08.24861
233014097	p_soroko	Паша	Сороко	2025-05-23 14:55:55.126384	2026-03-26 15:42:13.820735
830684363	katekharytonovich	Екатерина	\N	2025-05-26 11:10:05.85094	2025-05-26 11:10:05.866792
1399460408	\N	Евгений	\N	2025-05-29 20:41:47.385205	2025-05-29 20:41:47.401727
104574900	dibrest	Diana	Omelyanchuk (Nichiporuk)	2025-05-31 21:37:14.429982	2025-05-31 21:37:14.457178
1389427410	alexbut4er	Alex	But4er	2025-06-02 08:03:32.729454	2025-06-02 08:03:32.760468
6035372619	SERGKSM02	Serg	\N	2025-06-12 14:14:37.265467	2025-06-12 14:14:37.291295
174602964	hhh_ayas	Yulya	\N	2025-06-12 20:13:46.928878	2025-06-12 20:13:46.950544
670385571	DA_Vosem	Dmitry	\N	2025-06-23 19:21:36.441748	2025-06-23 19:21:36.458068
1237414435	\N	.Жан	\N	2025-06-24 19:08:42.468025	2025-06-24 19:08:42.485068
1710085904	\N	Катя 🦔	\N	2025-07-06 14:06:49.683531	2025-07-06 14:06:49.700793
5299302601	AlexeyAntonio	Antonov Aleksey	\N	2025-06-11 13:15:05.506516	2025-07-08 18:13:07.179915
1623979667	\N	Zamkovich	Anbrey	2025-05-26 11:12:04.172558	2025-08-12 10:58:46.268897
1157969661	\N	Светлана	\N	2025-08-14 10:34:29.983884	2025-08-14 10:34:30.00817
7586036325	\N	Бешки	\N	2025-08-14 11:46:32.237007	2025-08-14 11:46:32.249809
5852227700	\N	Сергей	Калиновский	2025-08-14 14:59:29.218067	2025-08-14 14:59:29.237928
8057088058	yulya_gerber	Юля	\N	2025-10-14 15:54:44.131722	2025-10-14 15:54:44.147385
6702107224	\N	Юрий	\N	2025-10-15 06:36:21.857525	2025-10-15 06:36:21.871891
159170948	rswissjaz1	Houston9	\N	2025-12-15 18:32:01.590272	2025-12-15 18:32:01.604541
796446310	\N	Татьяна	\N	2026-01-26 21:39:17.649341	2026-01-26 21:39:17.666023
670591083	gangsta_shits	Саня	Бугай	2026-02-20 21:40:18.632128	2026-02-20 21:40:18.650342
6306615927	\N	Марина	Щука	2026-03-19 12:58:12.541488	2026-03-19 12:58:12.55277
6095859689	\N	Karina	\N	2025-05-28 14:43:54.686362	2026-03-20 03:15:47.542155
965777550	yuliyashe_17	Юлия	\N	2025-05-26 11:24:41.551995	2026-03-20 13:48:47.250096
969550236	Danya_XA4	Danik	\N	2025-05-23 14:55:05.139749	2026-03-24 11:21:17.522171
5729687347	\N	Ecogas	Gazprom	2026-03-24 10:56:36.697648	2026-03-24 16:13:14.692366
7267201796	\N	Khaid	\N	2025-05-28 03:48:35.948874	2026-03-25 13:19:47.83259
\.


--
-- Name: admin_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_actions_id_seq', 45, true);


--
-- Name: contracts_legal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contracts_legal_id_seq', 3, true);


--
-- Name: contracts_physical_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contracts_physical_id_seq', 9, true);


--
-- Name: delayed_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delayed_messages_id_seq', 10, true);


--
-- Name: news_publications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.news_publications_id_seq', 52, true);


--
-- Name: questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.questions_id_seq', 20, true);


--
-- Name: admin_actions admin_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_actions
    ADD CONSTRAINT admin_actions_pkey PRIMARY KEY (id);


--
-- Name: agnks_users agnks_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agnks_users
    ADD CONSTRAINT agnks_users_pkey PRIMARY KEY (user_id);


--
-- Name: bot_settings bot_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bot_settings
    ADD CONSTRAINT bot_settings_pkey PRIMARY KEY (key);


--
-- Name: contracts_legal contracts_legal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts_legal
    ADD CONSTRAINT contracts_legal_pkey PRIMARY KEY (id);


--
-- Name: contracts_physical contracts_physical_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts_physical
    ADD CONSTRAINT contracts_physical_pkey PRIMARY KEY (id);


--
-- Name: delayed_messages delayed_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delayed_messages
    ADD CONSTRAINT delayed_messages_pkey PRIMARY KEY (id);


--
-- Name: moderators moderators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moderators
    ADD CONSTRAINT moderators_pkey PRIMARY KEY (user_id);


--
-- Name: news_publications news_publications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news_publications
    ADD CONSTRAINT news_publications_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: admin_actions_admin_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX admin_actions_admin_id_idx ON public.admin_actions USING btree (admin_id);


--
-- Name: admin_actions_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX admin_actions_created_at_idx ON public.admin_actions USING btree (created_at);


--
-- Name: agnks_users_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX agnks_users_user_id_idx ON public.agnks_users USING btree (user_id);


--
-- Name: contracts_legal_is_hidden_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contracts_legal_is_hidden_idx ON public.contracts_legal USING btree (is_hidden);


--
-- Name: contracts_legal_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contracts_legal_status_idx ON public.contracts_legal USING btree (status);


--
-- Name: contracts_legal_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contracts_legal_user_id_idx ON public.contracts_legal USING btree (user_id);


--
-- Name: contracts_physical_is_hidden_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contracts_physical_is_hidden_idx ON public.contracts_physical USING btree (is_hidden);


--
-- Name: contracts_physical_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contracts_physical_status_idx ON public.contracts_physical USING btree (status);


--
-- Name: contracts_physical_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX contracts_physical_user_id_idx ON public.contracts_physical USING btree (user_id);


--
-- Name: moderators_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX moderators_user_id_idx ON public.moderators USING btree (user_id);


--
-- Name: news_publications_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX news_publications_status_idx ON public.news_publications USING btree (status);


--
-- Name: news_publications_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX news_publications_user_id_idx ON public.news_publications USING btree (user_id);


--
-- Name: questions_answered_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX questions_answered_idx ON public.questions USING btree (answered_at) WHERE (answered_at IS NOT NULL);


--
-- Name: questions_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX questions_user_id_idx ON public.questions USING btree (user_id);


--
-- Name: users_username_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_username_idx ON public.users USING btree (username);


--
-- PostgreSQL database dump complete
--

\unrestrict 2EFeBx1FxdJnlQ7NlHbLW1nKumiQwOq1cSwtx4BOzPQfBsjR36ja492x2IrXysu

